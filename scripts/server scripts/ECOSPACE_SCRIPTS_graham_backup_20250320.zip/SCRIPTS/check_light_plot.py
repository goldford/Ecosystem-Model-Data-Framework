import numpy as np
import netCDF4 as nc
import os
from matplotlib import pyplot as plt

path='/project/6006412/goldford/ECOSPACE/DATA/light_hourly/'
light_f='RDRS21_NEMOgrid_light_1981.nc'